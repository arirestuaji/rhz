# -*- coding: utf-8 -*-
from akad.ttypes import *
from .server import Server
import requests, json

def loggedIn(func):
    def checkLogin(*args, **kwargs):
        if args[0].isLogin:
            return func(*args, **kwargs)
        else:
            args[0].callback.other('You want to call the function, you must login to LINE')
    return checkLogin

class Liff(object):
    isLogin = False

    def __init__(self):
        self.isLogin = True
        self.session = requests.session()
        self.liffToken = None
        self.liffHeader = {
            'Authorization': '',
            'User-Agent':  self.server.USER_AGENT,
            'Content-Type': 'application/json'
            }

    @loggedIn
    def revokeToken(self, accessToken):
        self.liff.revokeToken(RevokeTokenRequest(accessToken))

    @loggedIn
    def issueLiff(self, to, liffId="1562242036-RW04okm", isSquare=False):
        if self.liffToken:
            try:
                self.revokeToken(self.liffToken)
                self.liffToken = None
                self.liffHeader["Authorization"] = ''
            except:
                self.liffToken = None
                self.liffHeader["Authorization"] = ''
        if isSquare:
            context = LiffContext(squareChat=LiffSquareChatContext(to))
        else:
            context = LiffContext(chat=LiffChatContext(to))
        req = LiffViewRequest(liffId=liffId, context=context)
        try:
            resp = self.liff.issueLiffView(req)
        except:
            raise Exception("issueLiffView Failed (liffId is invalid or your token can't do this)")
        self.liffToken = resp.accessToken
        return self.liffToken

    @loggedIn
    def sendTempelate(self, data, revokeToken=True):
        try:
            self.liffHeader.update({'Authorization': 'Bearer ' + self.liffToken})
        except Exception as error:
            print(error)
        send = self.session.post(url=self.server.LINE_TEMPELATE_API, data=json.dumps(data), headers=self.liffHeader)
        if revokeToken:
            try:
                self.revokeToken(self.liffToken)
                self.liffToken = None
                self.liffHeader["Authorization"] = ''
            except:
                self.liffToken = None
                self.liffHeader["Authorization"] = ''
        return send
